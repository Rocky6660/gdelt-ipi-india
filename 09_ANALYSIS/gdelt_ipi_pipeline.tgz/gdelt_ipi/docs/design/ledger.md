# Ledger

## Model rotation plan (user asked to keep changing models)
| Round | Proposer / revisions | Reviewer | Red-team critic |
|---|---|---|---|
| Blind v1 | opus | – | – |
| 1 | – | sonnet | fable |
| 2 | opus (revision) | fable | sonnet |
| 3 | fable (revision) | opus | sonnet |
| 4 | opus (revision) | sonnet | fable |

Agreement rule: decision AGREED only if reviewer and critic both ACCEPT. Stop at ≥80% agreed and no FATAL, or after round 4.

## User constraints recorded 16 Nov 2026
- Paper (not thesis), deadline two weeks.
- BigQuery free sandbox.
- Pause for user approval after the design loop.
- All five extensions wanted.

## Rounds
(filled in as rounds complete)

## Blind round note
Proposer (opus) did not open user_ideas.md but did read the project memory note listing the user's five angles, so the blind round was only partly blind. Its independent overlap on (1) regional index and (2) language split should be weighed accordingly.
Proposer flagged for the user: validation audit would fetch live/Wayback copies of ~400 article URLs for coding — needs user confirmation this fits the "GDELT only" rule.

## Round 1 (reviewer sonnet, critic fable) on design_v1
| Decision | Reviewer | Critic | Status |
|---|---|---|---|
| D1 | REVISE | ACCEPT | open |
| D2 | ACCEPT | REVISE MINOR | open |
| D3 | REVISE | REVISE MINOR | open |
| D4 | REVISE | REVISE FATAL | open |
| D5 | REVISE | REVISE FATAL | open |
| D6 | REVISE | REVISE MINOR | open |
| D7 | ACCEPT | REVISE MINOR | open |
| D8 | REJECT | REVISE MINOR | open |
| D9 | REVISE | REVISE MINOR | open |
| D10 | ACCEPT | REVISE MINOR | open |
| D11 | ACCEPT | REVISE MINOR | open |
| D12 | ACCEPT | ACCEPT | AGREED |
| D13 | ACCEPT | ACCEPT | AGREED |
| D14 | ACCEPT | ACCEPT | AGREED |
| D15 | REVISE | REVISE MINOR | open |
| D16 | REVISE | ACCEPT | open |
| D17 | REVISE | REVISE MINOR | open |
| D18 | ACCEPT | ACCEPT | AGREED |
| D19 | REVISE | REVISE MINOR | open |
| D20 | REVISE | REVISE FATAL | open |
| D21 | ACCEPT | ACCEPT | AGREED |
| D22 | ACCEPT | REVISE MINOR | open |
| D23 | ACCEPT | ACCEPT | AGREED |
| D24 | ACCEPT | REVISE MINOR | open |
| D25 | REVISE | REVISE MINOR | open |
| D26 | REVISE | REVISE MINOR | open |
| D27 | REVISE | REVISE FATAL | open |
| D28 | REVISE | REVISE MINOR | open |
| D29 | ACCEPT | REVISE MINOR | open |
| D30 | ACCEPT | ACCEPT | AGREED |
| D31 | ACCEPT | REVISE MINOR | open |
| D32 | ACCEPT | REVISE MINOR | open |
| D33 | ACCEPT | REVISE MINOR | open |
| D34 | REVISE | REVISE FATAL | open |
| D35 | ACCEPT | REVISE MINOR | open |
| D36 | ACCEPT | ACCEPT | AGREED |
| D37 | REVISE | REVISE MINOR | open |

Agreement: 8/37 = 22%. FATAL: D4, D5, D20, D27, D34. Not stopped.

## Round 2 (reviewer fable, critic sonnet) on design_v2
| Decision | Reviewer | Critic | Status |
|---|---|---|---|
| D1 | ACCEPT | REVISE MINOR | open |
| D2 | ACCEPT | ACCEPT | AGREED |
| D3 | ACCEPT | REVISE MINOR | open |
| D4 | REVISE | REVISE MINOR | open |
| D5 | ACCEPT | REVISE MINOR | open |
| D6 | ACCEPT | REVISE MINOR | open |
| D7 | ACCEPT | REVISE MINOR | open |
| D8 | ACCEPT | ACCEPT | AGREED |
| D9 | ACCEPT | REVISE MINOR | open |
| D10 | ACCEPT | ACCEPT | AGREED |
| D11 | REVISE | REVISE MINOR | open |
| D12 | ACCEPT | ACCEPT | AGREED |
| D13 | ACCEPT | ACCEPT | AGREED |
| D14 | ACCEPT | ACCEPT | AGREED |
| D15 | REVISE | REVISE MINOR | open |
| D16 | ACCEPT | REVISE MINOR | open |
| D17 | ACCEPT | REVISE MINOR | open |
| D18 | ACCEPT | ACCEPT | AGREED |
| D19 | ACCEPT | REVISE MINOR | open |
| D20 | ACCEPT | REVISE MINOR | open |
| D21 | ACCEPT | ACCEPT | AGREED |
| D22 | ACCEPT | REVISE MINOR | open |
| D23 | ACCEPT | ACCEPT | AGREED |
| D24 | ACCEPT | ACCEPT | AGREED |
| D25 | ACCEPT | REVISE MINOR | open |
| D26 | ACCEPT | REVISE MINOR | open |
| D27 | ACCEPT | REVISE MINOR | open |
| D28 | REVISE | ACCEPT | open |
| D28.2 | - | ACCEPT | open |
| D29 | ACCEPT | REVISE MINOR | open |
| D30 | ACCEPT | REVISE MINOR | open |
| D31 | ACCEPT | ACCEPT | AGREED |
| D32 | ACCEPT | REVISE MINOR | open |
| D33 | ACCEPT | REVISE MINOR | open |
| D34 | REVISE | REVISE MINOR | open |
| D35 | ACCEPT | ACCEPT | AGREED |
| D36 | ACCEPT | ACCEPT | AGREED |
| D37 | ACCEPT | REVISE MINOR | open |
| D38 | ACCEPT | REVISE MINOR | open |
| D39 | ACCEPT | ACCEPT | AGREED |
| D40 | ACCEPT | REVISE MINOR | open |
| D41 | ACCEPT | ACCEPT | AGREED |
| D42 | REVISE | REVISE MINOR | open |

Agreement: 16/43 = 37% (D28.2 removal accepted by reviewer in text). FATAL: none. Not stopped. Reviewer alone 86% ACCEPT; critic gave 26 REVISE MINOR.

## Round 3 (reviewer opus, critic sonnet) on design_v3
| Decision | Reviewer | Critic | Status |
|---|---|---|---|
| D1 | ACCEPT | ACCEPT | AGREED |
| D2 | ACCEPT | REVISE MINOR | open |
| D3 | ACCEPT | ACCEPT | AGREED |
| D4 | ACCEPT | ACCEPT | AGREED |
| D5 | ACCEPT | ACCEPT | AGREED |
| D6 | ACCEPT | ACCEPT | AGREED |
| D7 | ACCEPT | REVISE MINOR | open |
| D8 | ACCEPT | ACCEPT | AGREED |
| D9 | ACCEPT | ACCEPT | AGREED |
| D10 | ACCEPT | ACCEPT | AGREED |
| D11 | ACCEPT | ACCEPT | AGREED |
| D12 | ACCEPT | ACCEPT | AGREED |
| D13 | ACCEPT | ACCEPT | AGREED |
| D14 | ACCEPT | ACCEPT | AGREED |
| D15 | ACCEPT | ACCEPT | AGREED |
| D16 | REVISE | ACCEPT | open |
| D17 | ACCEPT | ACCEPT | AGREED |
| D18 | ACCEPT | ACCEPT | AGREED |
| D19 | ACCEPT | REVISE MINOR | open |
| D20 | ACCEPT | ACCEPT | AGREED |
| D21 | ACCEPT | ACCEPT | AGREED |
| D22 | ACCEPT | ACCEPT | AGREED |
| D23 | ACCEPT | ACCEPT | AGREED |
| D24 | ACCEPT | ACCEPT | AGREED |
| D25 | REVISE | ACCEPT | open |
| D26 | ACCEPT | ACCEPT | AGREED |
| D27 | REVISE | ACCEPT | open |
| D28 | ACCEPT | REVISE MINOR | open |
| D29 | ACCEPT | ACCEPT | AGREED |
| D30 | ACCEPT | ACCEPT | AGREED |
| D31 | ACCEPT | ACCEPT | AGREED |
| D32 | ACCEPT | ACCEPT | AGREED |
| D33 | ACCEPT | ACCEPT | AGREED |
| D34 | ACCEPT | REVISE MINOR | open |
| D35 | ACCEPT | ACCEPT | AGREED |
| D36 | ACCEPT | ACCEPT | AGREED |
| D37 | ACCEPT | ACCEPT | AGREED |
| D38 | ACCEPT | ACCEPT | AGREED |
| D39 | ACCEPT | ACCEPT | AGREED |
| D40 | ACCEPT | ACCEPT | AGREED |
| D41 | ACCEPT | ACCEPT | AGREED |
| D42 | ACCEPT | ACCEPT | AGREED |

Agreement: 35/43 = 81.4% (D28.2 removal accepted by both; critic listed it as REMOVED-shift-share-IV). FATAL: none. STOP RULE MET (≥80%, no FATAL). Extra critic items (demoted/removed sub-choices) not in reviewer's list: []

## User rulings (17 Nov 2026, 13:44 IST)
- Disputes D2, D7, D16, D19, D25, D27, D28, D34: ALL proposed fixes ACCEPTED.
- D16 audit text: Mode A APPROVED (live + archived fetch of ~400 articles, validation only, log success/failure), GDELT/NGrams fallback where needed.
- BigQuery project ID: gdelt-508903 (sandbox).
- Project folder GDELT_IPI: prepared by user; attachment PENDING verification.
- Human coding: APPROVED, ~4.5 h across days 4–5.
- Requirements: full scope retained, all five extensions, no downgrades for deadline; budget 0.55–0.67 TB; dry-run + hard byte caps on every job; freeze outlets and query plan before major extraction; separate raw/processed/scripts/logs/docs; gates before claims; descriptive versions of extensions even if gates fail; no fabrication; no causal claims; report blockers.
- Deadline: 25 Nov 2026.

## User rulings, 17 Nov 2026 18:40 IST
- Audit fetch: all ~1,550 sampled articles (no 400 cap).
- Languages: Marathi/Bengali articles stay in the dataset; classified by LLM only (user does not read them). Human sheet stays English + Hindi (110 + 40).
- LLM coding: option B, done in-session by Claude Opus directly; no agent workflow.
- Execution: Opus only; no subagents, reviewer/verifier agents, or parallel model reviews. Second-agent reproduction (verification by a different model) is dropped by user instruction; replaced by a scripted self-check (rerun from raw, compare hashes/figures).
- Blocker logged: both the cloud workspace and the desktop sandbox block GDELT, BigQuery, RBI, MoSPI, FRED, Wayback and news hosts (only PyPI/Anthropic reachable).
